<?php
	require_once '../private/bin/index.php';
?>